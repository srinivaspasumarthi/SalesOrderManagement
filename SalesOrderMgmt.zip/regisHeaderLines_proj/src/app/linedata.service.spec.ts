import { TestBed } from '@angular/core/testing';

import { LinedataService } from './linedata.service';

describe('LinedataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LinedataService = TestBed.get(LinedataService);
    expect(service).toBeTruthy();
  });
});
