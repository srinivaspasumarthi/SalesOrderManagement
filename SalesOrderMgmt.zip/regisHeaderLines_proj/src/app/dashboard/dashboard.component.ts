import { Component, OnInit } from '@angular/core';
import {LocalStorageService} from 'ngx-localstorage';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  public username;

  constructor(private local: LocalStorageService  , private router: Router) {
    console.log('Constructor called');
   }

  ngOnInit() {
    console.log('Dashboard init');
    this.username = this.local.get('username');
    if (this.username == null || this.username === undefined || this.username === '') {
      this.router.navigate(['/']);
    }
    console.log('Dashboard init completed');
  }
  loadComponent() {
    this.router.navigate(['/dashboard/header']);
  }
  logout() {
    this.local.remove('username');
    this.local.remove('password');
    this.router.navigate(['/']);
  }

}
