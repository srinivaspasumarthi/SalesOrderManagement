import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import {NgPipesModule} from 'ngx-pipes';

import { HeaderComponent } from '../header/header.component';
import { LinesComponent } from '../lines/lines.component';
import { ReactiveFormsModule } from '@angular/forms';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { ViewComponent } from '../view/view.component';
import { OrderviewComponent } from '../orderview/orderview.component';
import { OrdereditComponent } from '../orderedit/orderedit.component';
import { LogincheckService } from '../logincheck.service';
import { DataService } from '../data.service';
import { LinedataService } from '../linedata.service';


const routing: Routes = [
  {
    path: '',
    component: DashboardComponent,
    children: [ {
      path: 'header',
      component: HeaderComponent
       ,
       children: [{
         path: 'lines',
         component: LinesComponent
       } ]
    },
      {
        path: 'view',
        component: ViewComponent
      },
      {
        path: 'orderdetail/:id',
        component: OrderviewComponent
      },
      {
        path: 'orderedit/:id',
        component: OrdereditComponent,
        canActivate: [LogincheckService],
        resolve: {
          orderdata : DataService ,
          linedata : LinedataService
        }
      }
  ]
  },
];

@NgModule({
  declarations: [HeaderComponent , LinesComponent , DashboardComponent ,
    ViewComponent , OrderviewComponent , OrdereditComponent],
  imports: [
    CommonModule, NgPipesModule , RouterModule, FormsModule, ReactiveFormsModule , RouterModule.forChild(routing)
  ],
  providers: [DataService , LinedataService]
})
export class DashboardModule { }
