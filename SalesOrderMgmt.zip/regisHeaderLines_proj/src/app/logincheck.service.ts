import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRoute } from '@angular/router';
import { LocalStorageService } from 'ngx-localstorage';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})

export class LogincheckService  implements CanActivate {
  constructor(private local: LocalStorageService , private router: Router ) { }
  canActivate() {
    console.log('canactivate: Checking routing');
   // console.log(this.route.snapshot.params.id);
    if (this.local.get('username') == null) {
      this.router.navigate(['/']);

   } else {

   }

    return true;
  }

}
