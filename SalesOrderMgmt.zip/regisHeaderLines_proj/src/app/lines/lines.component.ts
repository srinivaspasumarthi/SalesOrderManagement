import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DataService } from '../data.service';

interface Linesdata {
  linenum: number ;
  itemname: any ;
  quantity: number ;
  warehouse?: any ;
  custname?: any ;
  ordernumber: any ;
}

@Component({
  selector: 'app-lines',
  templateUrl: './lines.component.html',
  styleUrls: ['./lines.component.scss']
})
export class LinesComponent implements OnInit {

  @Input() mydata: any;
  @Output() passData = new EventEmitter();
localordernumber ;
  public LineData: Linesdata[] = [
 //   { linenum: 1, itemname: 'Camera', quantity: 3, warehouse: 'W1', custname: 'Samanta', ordernumber: 121},
 //   { linenum: 2, itemname: 'Bike', quantity: 1, warehouse: 'W3', custname: 'Raj', ordernumber: 121},
 //   { linenum: 3, itemname: 'Pens', quantity: 20, warehouse: 'W2', custname: 'Shannu', ordernumber: 121}
  ];
  LineFormData = null;

  formData = {
    id: null,
    custName: null,
    custAddress: null,
    paymentType: null,
    custType: null,
    orderTotal: null
  };
  public formShow = false;
  // data = [
  //   { id : 1 , custName : 'Srini', custAddress: 'Srini-Address', paymentType: 'Cash', custType: 'Prime', orderTotal: 2000},
  //   { id : 2 , custName : 'Vasu', custAddress: 'Vasu-Address', paymentType: 'Cash', custType: 'Secondary', orderTotal: 3000},
  //   { id : 3 , custName : 'Ramu', custAddress: 'Ramu-Address', paymentType: 'Card', custType: 'Prime', orderTotal: 2500},
  //   { id : 4 , custName : 'Venkat', custAddress: 'Venkat-Address', paymentType: 'Card', custType: 'Prime', orderTotal: 5000},  
  // ];
  public data;
  constructor(private dataService: DataService) {
    console.log('In lines constructor');
    console.log(this.data);
  }

  ngOnInit() {
    console.log('in lines onInit');
    console.log(this.mydata);
    this.data = this.mydata;
    this.dataService.currentMessage.subscribe(message => this.localordernumber = message);
    console.log('latest order number' + this.localordernumber);
   // this.data.currentMessage.subscribe(message => this.localordernumber = message);
   // console.log(this.localordernumber);
  }

  displayform() {
    this.formShow = true;
    var countRec = this.data.length;
    this.formData.id = countRec + 1;
  }
addDataToLines(data) {
    console.log('Data passed to lines');
    console.log(data);
}
  addData() {
    //this.data.push(this.formData) ;
    this.passData.emit(this.formData); //Passing formdata(Latest rec) to parent component.
    // console.log("Emitting done");
    // this.data = this.mydata;
    // console.log(this.mydata);
    var countRec = this.data.length;
    var nextId = countRec + 1;
    //Creating next rec with empty fields.
    this.formData = {
      id: nextId,
      custName: null,
      custAddress: null,
      paymentType: null,
      custType: null,
      orderTotal: null
    };
  }



  addLines() {
    console.log('In add lines');
    var countRec = this.LineData.length;
    var nextId = countRec + 1;
    this.LineFormData = {
      linenum: nextId,
      itemname: null,
      quantity: null,
      warehouse: null,
      custname: null,
      ordernumber: this.localordernumber
    };
    this.LineData.push(this.LineFormData);
    console.log(this.LineData);
  }
  saveLines() {
    console.log(this.LineData);
    if (this.LineData.length == 0 ) {
      alert('Please add lines.');
      return;
    }
    this.dataService.linesInsert(this.LineData).subscribe(
      (success) => {
        console.log(success);
        alert('Order is created');
      },
      (error) => {
        console.log(error);
        alert('Order creation failed. Please check log files');
      }
    );
  }
}
