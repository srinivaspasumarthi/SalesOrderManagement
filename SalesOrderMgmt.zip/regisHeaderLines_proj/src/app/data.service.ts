import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { observable, Observable , BehaviorSubject } from 'rxjs';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class DataService implements Resolve<Observable<string>> {

  private messageSource = new BehaviorSubject(1);
  currentMessage = this.messageSource.asObservable();

  changeMessage(message: number) {
    this.messageSource.next(message);
    console.log(message);
  }

  constructor(private http: HttpClient , private router: Router) { }

  resolve( route: ActivatedRouteSnapshot,  state: RouterStateSnapshot) {
    console.log('resolve in dataservice');
    console.log(route.params.id);
    console.log(this.getHeader(route.params.id));
    this.getHeader(route.params.id).subscribe(
      (success) => {
        console.log(success);
        if (success.data.length == 0) {
          alert('Order ' + route.params.id + ' does not exist');
          this.router.navigate(['/dashboard/view']);
        }
            },
      (error) => {
        alert('Order ' + route.params.id + ' does not exist');
        this.router.navigate(['/dashboard/view']);
      }
    );
    return this.getHeader(route.params.id);
  }

  registration(data): Observable<any> {
    var response = this.http.post('http://localhost:9999/crud/user/create', data );
    return response ;
  }

  login(data): Observable<any> {
    var response = this.http.post('http://localhost:9999/crud/user/login', data );
    return response ;
  }
  header(data): Observable<any> {
    var response = this.http.post('http://localhost:9999/crud/order/header/create', data );
    return response ;
  }
  maxOrderNumber(): Observable<any> {
    var response = this.http.get('http://localhost:9999/crud/header/maxordernumber');
    return response ;
  }
  linesInsert(data): Observable<any> {
    var response = this.http.post('http://localhost:9999/crud/order/lines/create', data);
    return response ;
  }
  getHeaders(): Observable<any> {
    var response = this.http.get('http://localhost:9999/crud/get/headers');
    return response ;
  }
  getHeader(data): Observable<any> {
    var response = this.http.get('http://localhost:9999/crud/get/header?id=' + data);
    return response ;
  }
  updateHeader(data): Observable<any> {
    var response = this.http.post('http://localhost:9999/crud/update/header', data);
    return response ;
  }
  updateLine(data): Observable<any> {
    var response = this.http.post("http://localhost:9999/crud/update/line" , data);
    //var response = this.http.post('http://localhost:9999/crud/update/header', data);
    return response ;
  }
  updateLines(data): Observable<any> {
    var response = this.http.post("http://localhost:9999/crud/update/lines" , data);
    //var response = this.http.post('http://localhost:9999/crud/update/header', data);
    return response ;
  }
  getLines(data): Observable<any> {
    var response = this.http.get('http://localhost:9999/crud/get/lines?id=' + data);
    return response ;
  }
  deleteOrder(data): Observable<any>  {
    console.log(data);
    var response = this.http.delete('http://localhost:9999/crud/orders/delete?id=' + data);
    return response;
  }
}
