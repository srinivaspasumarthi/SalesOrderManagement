import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';
interface HeaderContent {
  header_id ?: any;
  order_number: any;
  cust_name: any;
  cust_address: any;
  payment_type: any;
  cust_type: any;
  order_total ?: any ;
}

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent implements OnInit {
   headers ;
   search ;
  constructor(private dataservice: DataService ,  private router: Router ) {
    this.dataservice.getHeaders().subscribe(
      (success) => {
        console.log(success);
        this.headers = success.data;
        console.log(this.headers);
      },
      (error) => {
        console.log(error);
      }
    );
   }

   deleteOrder(header) {
    console.log(header.order_number);
    let orderobjs = this.headers;
    console.log(orderobjs);
    console.log(this.headers);

    this.dataservice.deleteOrder(header.order_number).subscribe(
      (success) => {
        console.log(success);
        for ( var i = 0; i < this.headers.length ; i++) {
          if ( this.headers[i].order_number == header.order_number ) {
               this.headers.splice(i, 1);
               console.log(this.headers[i].order_number);
          }
        }
        console.log(this.headers);
        // console.log(orderobjs.length);
    /*  for (let i = 0 ; i < orderobjs.length ; i++) {
         if (orderobjs[i].order_number == id ) {
          console.log(orderobjs[i]);
           orderobjs.splice(i,1);
          console.log(orderobjs);
         }
        }
        this.headers = orderobjs;*/
      },
     (error) => {
      console.log(error);
     }
      );
   }
  ngOnInit() {
  }

}
