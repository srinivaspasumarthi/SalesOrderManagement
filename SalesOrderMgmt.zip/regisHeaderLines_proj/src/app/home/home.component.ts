import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';
import { DashboardComponent } from '../dashboard/dashboard.component';
import {LocalStorageService} from 'ngx-localstorage';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  loginMessage = false ;
  constructor(private dataservice: DataService , private router: Router , private local: LocalStorageService ) {

  }

  public data = {
    name: null ,
    email: null,
    phone: null,
    username: null,
    password: null
  };

  public loginData = {
   username: null,
   password: null
  };

  login() {
    this.dataservice.login(this.loginData).subscribe
     (
      (success) => {
       console.log(success);
       if ( success.response == 0) {
         this.loginMessage = true;
         this.loginData = {
           username: null,
           password: null
         };
       } else {
         this.local.set('username', this.loginData.username);
         this.local.set('password', this.loginData.password);
         console.log('navigating');
         this.router.navigate(['dashboard']);
       }
      },
      (error) => {
        console.log(error);
      } );
  }
  ngOnInit() {

  }
 registration() {
    console.log(this.data);
    //this.http.post('http://localhost:9999/crud/user/create', this.data).subscribe
    this.dataservice.registration(this.data).subscribe
     (
      (success) => {
       console.log(success);
      },
      (error) => {
        console.log(error);
      } );
  }
}
