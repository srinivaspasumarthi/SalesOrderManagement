import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../data.service';
import { LinedataService } from '../linedata.service';

interface HeaderContent {
  header_id ?: any;
  order_number: any;
  cust_name: any;
  cust_address: any;
  payment_type: any;
  cust_type: any;
  order_total ?: any ;
}

@Component({
  selector: 'app-orderedit',
  templateUrl: './orderedit.component.html',
  styleUrls: ['./orderedit.component.scss']
})

export class OrdereditComponent implements OnInit {
  localid;
  lineobjects;
  headerReadonly = false;
  lineReadonly = false ;
  public headerObj: HeaderContent ;
  public headerSaved = false ;
 constructor(private route: ActivatedRoute, private dataservice: DataService, private linedataservice: LinedataService) {
    console.log(this.route.snapshot.params.id);
    console.log(this.route.snapshot.params);
    this.localid = this.route.snapshot.params.id;
    console.log(this.route.data);
    this.route.data.subscribe(
      (success) => {
        console.log(success.orderdata.data[0]);
        this.headerObj = success.orderdata.data[0];
      }
    );
    this.route.data.subscribe(
      (success) => {
        console.log(success);
        console.log(success.linedata.data);
        this.lineobjects = success.linedata.data;
      }
    );
   // this.route.data.map(data => data.orderdata.json()).subscribe((res) => {
     // console.log(res);
    // });
   /* this.dataservice.getHeader(this.localid).subscribe(
      (success) => {
        console.log(success);
        console.log(success.data);
        this.headerObj = success.data ;
      },
      (error) => {
        console.log(error);
     }
    );*/

   }

  ngOnInit() {
  }

  updateHeaderData() {
    console.log('In update header data');
    this.headerReadonly = true;
    console.log(this.headerObj);
    this.dataservice.updateHeader(this.headerObj).subscribe(
    (success) => {
    console.log(success);
    this.headerSaved = true ;
    },
    (error) => {
      console.log(error);
    }
    );
  }
  updateLine(row) {
    console.log('In updateLine');
   console.dir(row);
    this.dataservice.updateLine(row).subscribe(
      (success) => {
        console.log(success);
      },
      (error) => {
        console.log(error);
      }
    );
  }
  updateLines() {
    this.lineReadonly = true ;
    console.log('In update lines');
    console.log(this.lineobjects);
    this.dataservice.updateLines(this.lineobjects).subscribe(
      (success) => {
      console.log(success);
      },
      (error) => {
        console.log(error);
      }

    )
  }
}
