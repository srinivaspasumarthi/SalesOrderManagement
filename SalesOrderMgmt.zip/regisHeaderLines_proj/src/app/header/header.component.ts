import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

interface Header {
  cust_name: any ;
  cust_type: any ;
  order_number: any;
  cust_address: any ;
  payment_type: any;
}

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  fmdetails: FormGroup ;
  headerData: Header;
  headerSaved = false ;
  // tslint:disable-next-line:variable-name
  public max_order_number: number;
  constructor(private fb: FormBuilder, private router: Router , private dataservice: DataService) {
    console.log('In constructor');
    // this.fmdetails  = this.fb.group({
    //   cust_name : [''],
    //   cust_type :  ['', Validators.required],
    //   order_number :  [{value: '', disabled: true}, Validators.required],
    //   cust_address :  ['', Validators.required],
    //   payment_type : ['', Validators.required]
    // });
    // console.log(this.fmdetails.value);
  }

  ngOnInit() {
    console.log('in header onInit');
    this.fmdetails  = this.fb.group({
      cust_name : [''],
      cust_type :  ['', Validators.required],
      order_number :  [{value: '', disabled: true}, Validators.required],
      cust_address :  ['', Validators.required],
      payment_type : ['', Validators.required]
    });
    console.log(this.fmdetails.value);
    this.dataservice.maxOrderNumber().subscribe
    (
     (success) => {
      console.log(success);
      this.max_order_number = success.data[0].max_order_number + 1 ;
      this.fmdetails.patchValue({
        order_number: this.max_order_number
      });
    /*  this.fmdetails.setValue({cust_name: null,
         cust_type: 'Important' ,
         order_number: this.max_order_number ,
         cust_address: null,
         payment_type: null
        }); */
      console.log(this.fmdetails.controls);
      console.log(this.fmdetails.value);
     },
     (error) => {
       console.log(error);
     } );
  }

  get formdata() { return this.fmdetails.controls; }

  submitheader() {
    console.log(this.fmdetails.controls);
    if (this.fmdetails.invalid) {
      alert('Please enter all details');
      this.router.navigate(['/dashboard/header']);
      return;
    }
    console.log(this.fmdetails.controls);
    console.log(this.fmdetails.value);
    this.headerData = this.fmdetails.value ;
    this.headerData.order_number = this.fmdetails.get('order_number').value;
    console.log(this.headerData);
    this.dataservice.header(this.headerData).subscribe
    (
     (success) => {
      console.log(success);
      this.fmdetails.disable();
      this.changeMessageHeader();
      this.headerSaved = true ;
      this.router.navigate(['/dashboard/header/lines']);
      console.log('header submission success');
       },
     (error) => {
       console.log(error);
       alert('Failed to save header. Check log');
     } );
    console.log('header submitted');
  }

  clearform() {
    console.log('clear form');
    this.fmdetails.reset();
    this.fmdetails.enable();
    //this.fmdetails.controls[order_number].disable({onlySelf: true});
    this.fmdetails.get('order_number').disable();
    this.ngOnInit();
    console.log(this.headerData);
    this.headerSaved = false ;
  }

  changeMessageHeader() {
    console.log('Calling change message');
    console.log(this.headerData.order_number);
    this.dataservice.changeMessage(this.headerData.order_number);

  }

}

/*import { Component, OnInit, ViewEncapsulation ,  Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

interface HeaderContent {
   header_id ?: any;
   order_number: any;
   cust_name: any;
   cust_address: any;
   payment_type: any;
   cust_type: any;
   order_total ?: any ;
 }

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class HeaderComponent implements OnInit {

  headerReadonly = false ;
  public  max_order_number;
  headerSaved = false ;
  public headerObj: HeaderContent = {
    header_id : this.max_order_number ,
    order_number: this.max_order_number ,
    cust_name: null ,
    cust_address: null ,
    payment_type: null ,
    cust_type: null ,
    order_total: null
  };
  @Output() passData = new EventEmitter();

  data = [
   ];


  ngOnInit() {
    console.log('in header onInit');
    console.log(this.data);
    this.dataservice.maxOrderNumber().subscribe
    (
     (success) => {
      console.log(success);
      console.log(success.data[0].max_order_number);
      this.max_order_number = success.data[0].max_order_number + 1 ;
      console.log(this.max_order_number);
     },
     (error) => {
       console.log(error);
     } );

  }
  constructor(private dataservice: DataService , private router: Router) {
   /* this.dataservice.maxOrderNumber().subscribe
    (
     (success) => {
      console.log(success);
      console.log(success.data[0].max_order_number);
      this.max_order_number = success.data[0].max_order_number + 1 ;
      console.log(this.max_order_number);
     },
     (error) => {
       console.log(error);
     } );

    this.headerObj = {
      header_id : this.max_order_number ,
      order_number: this.max_order_number ,
      cust_name: null ,
      cust_address: null ,
      payment_type: null ,
      cust_type: null ,
      order_total: null
    };*/
 /* }

  public saveHeaderData() {
    this.headerReadonly = true;
    this.headerObj.order_number = this.max_order_number;
    this.headerObj.header_id = this.max_order_number;
    this.data.push(this.headerObj);
    console.log(this.headerObj);
    console.log('Header Data is Submitted');
    this.passData.emit(this.headerObj); //emitt headerObj data to other components.
    this.dataservice.header(this.headerObj).subscribe
    (
     (success) => {
      console.log(success);
      this.headerSaved = true ;
     },
     (error) => {
       console.log(error);
       this.headerReadonly = false;
       alert('Failed to save header. Check log');
     } );
    this.changeMessageHeader();
  //  this.dataservice.currentMessage.subscribe(message => this.headerObj.order_number = message);
  // console.log(this.headerObj.order_number);
  }
  changeMessageHeader() {
    console.log('Calling change message');
    console.log(this.headerObj.order_number);
    this.dataservice.changeMessage(this.headerObj.order_number);

  }

}
*/